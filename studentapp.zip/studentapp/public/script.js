// Add Student (CREATE)
function addStudent() {
  const name = document.getElementById("name").value;
  const age = document.getElementById("age").value;
  const course = document.getElementById("course").value;

  if (!name || !age || !course) {
    alert("All fields required");
    return;
  }

  fetch("/students", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      name: name,
      age: age,
      course: course
    })
  })
    .then(res => res.json())
    .then(() => {
      document.getElementById("name").value = "";
      document.getElementById("age").value = "";
      document.getElementById("course").value = "";
      loadStudents();
    });
}

// Load Students (READ)
function loadStudents() {
  fetch("/students")
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("list");
      list.innerHTML = "";

      data.forEach(s => {
        list.innerHTML += `
          <li>
            ${s.name} - ${s.age} - ${s.course}
            <button onclick="deleteStudent('${s._id}')">Delete</button>
          </li>
        `;
      });
    });
}

// Delete Student (DELETE)
function deleteStudent(id) {
  fetch(`/students/${id}`, {
    method: "DELETE"
  })
    .then(res => res.json())
    .then(() => {
      loadStudents();
    });
}

// Page load par data show ho
loadStudents();
