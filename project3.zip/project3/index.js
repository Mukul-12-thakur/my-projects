// prompt("enter you age")
// alert("")
// console.log("print data in")
// console.error("print the error")
// console.warn("print the")//
// let a = 35
// let b = 35
// console.log(a+b)
// console.log(a-b)
// console.log(a*b)
// console.log(a/b)
// console.log(a%b)
 
// let a=35
// let b=20
// console.log(a%b)
// a+=20
// a*=20
// a-=55
// console.log(a)
// let a=35
// let b=35
// console.log(a>b)
// console.log(a<b)
// console.log(a<=b)
// console.log(a==b)
// console.log(a===b)
// console.log(a>=b)
// console.log(a!=b)

function fun()
{
var a=document.getElementById("mail").value;
var b=document.getElementById("psw").value;
if(a=='p' && b=='123')
{
    alert("login succesfull");

    location.assign("./index.html");
}


else
{
    alert("wrong creditionals");
}
}
